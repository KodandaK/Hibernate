package com.kk.domain;

public class RegularEmployee extends Employee{
 private long qplc;

public long getQplc() {
	return qplc;
}

public void setQplc(long qplc) {
	this.qplc = qplc;
}
 
}
