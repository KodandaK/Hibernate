package com.kk.domain;

public class ContractEmployee extends Employee{
	private long allowance;

	public long getAllowance() {
		return allowance;
	}

	public void setAllowance(long allowance) {
		this.allowance = allowance;
	}
	

}
