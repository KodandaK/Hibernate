package com.kk.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.kk.domain.ContractEmployee;
import com.kk.domain.Employee;
import com.kk.domain.RegularEmployee;

public class ClientClass {

	public static void main(String[] args) {

		Configuration cfg = null;
		SessionFactory factory = null;
		Session ses = null;
		Employee emp = null;
		RegularEmployee regEmp=null;
		ContractEmployee conEmp=null;

		Transaction tx = null;
		// activation of HB Framwork
		cfg = new Configuration();
		// read both mapping, cfg file data
		cfg = cfg.configure("/com/kk/cfgs/hibernate.cfg.xml");
		// build session factory
		factory = cfg.buildSessionFactory();
		// open session with DB s.w
		ses = factory.openSession();
		
		// create obj for Domain class
		emp = new Employee();

		// Saving an Objects
		emp.setEmployeeId("LG90354");
		emp.setEmployeeName("Loghesh");
		emp.setEmployeeSalary(30234);
		
		regEmp=new RegularEmployee();
		regEmp.setEmployeeId("NO346834");
		regEmp.setQplc(4000);
		
		conEmp=new ContractEmployee();
		conEmp.setEmployeeId("SR6788");
		conEmp.setAllowance(3000);
		
		
		try {
			tx = ses.beginTransaction();
			ses.save(regEmp);
			ses.save(conEmp);
			tx.commit();
			System.out.println("Obj is saved");

		} catch (Exception e) {
			tx.rollback();
		}

		
		// Deleting an Contract Employee Object
		emp = (Employee) ses.get(Employee.class, "KK74557");
		if (emp != null) {
			try {
				tx = ses.beginTransaction();
				ses.delete(conEmp);
				tx.commit();
				System.out.println("Record is deleted ");
			} catch (Exception e) {
				tx.rollback();
			}
		} else
			System.out.println("For Deletion Record is not found");

		// close object
		ses.close();
		factory.close();
		System.out.println("Connections have been closed........");

	}

}
